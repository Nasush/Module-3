package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "NameServletName", urlPatterns = { "/NameServletMap" })
public class NameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public NameServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Name Servlet init call");
	}

	
	public void destroy() {
		System.out.println("Name Servlet destroy call");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nm=request.getParameter("txtName");
		String nm2=request.getParameter("txtName1");

		PrintWriter pw=response.getWriter();
		pw.println("<b>Welcome</b>"+nm);
		pw.println("Password is:" +nm2);
		
		
	}

}
