package com.capgemini.tcc.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client 
{
	static Scanner sc=null;
    static IPatientService patSer=null;
    public static void main(String[] args)
    {
    	patSer=new PatientService();
        sc=new Scanner(System.in);
        int choice=0;
        while(true)
        {
        	System.out.println("1.Add Patient Information\n"
        			+ "2.Search Patient By Id\n"
        			+ "3.Exit");
        	choice=sc.nextInt();
            switch(choice)
            {
            case 1: AddPatientInfo();
            break;
            case 2: SearchPatient();
            break;
            case 3: 
            	System.out.println("I am bored");
            	System.exit(0);
            break;
            default:
            	System.out.println("Invalid Input");
            	break;
            }
        }
}
    private static void AddPatientInfo() 
	{
		System.out.println("Enter the name of the Patient:");
		String name=sc.next();
		try
		{
		if(patSer.validateName(name))
        {
		System.out.println("Enter Patient Age:");
		int age=sc.nextInt();
		if(patSer.validateAge(age))
        {
		System.out.println("Enter Patient phone number:");
		String phoneNo=sc.next();
		if(patSer.validatePhoneNo(phoneNo))
        {
		System.out.println("Enter Description:");
		String description=sc.next();
		 
		if(patSer.validateDescription(description))
        {
	
			PatientBean patient=new PatientBean();
			 patient.setPatientName(name);
			 patient.setAge(age);
			 patient.setPhoneNo(phoneNo);
			 patient.setDescription(description);
			 int dataAdded=patSer.addPatientDetails(patient);
			
             if(dataAdded>0)
             {
             	 System.out.println("Patient Information"
             	 		+ " stored successfully for"+dataAdded);
             }
        }
        else
        {
        	System.out.println("May some exception occurs");
        	
        }
		
        }
	
        }
        }
		}
		 catch (PatientException e)
        {

            System.out.println(e.getMessage());
        }
	}
		
	private static void SearchPatient() 
	{
		
		try
		{
			System.out.println("Enter the patient id");
			int patientId=sc.nextInt();
			if(patSer.validatePatientId(patientId))
			{
			PatientBean pb=patSer.getPatientDetails(patientId);
			System.out.println(pb);
			
			}
			else
			{
				System.out.println("There is no patient with this ID");
			}
		} 
		    
		    catch(PatientException e)
		    {
		    	 System.out.println(e.getMessage());
		    }
			 

        
}
		
	}


	