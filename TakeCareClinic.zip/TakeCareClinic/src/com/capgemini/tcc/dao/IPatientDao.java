package com.capgemini.tcc.dao;

import java.util.ArrayList;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;


public interface IPatientDao
{
	public int addPatientDetails(PatientBean patient)throws PatientException;
	public PatientBean getPatientDetails(int patientId)throws PatientException;
	public int generatePatientId()throws PatientException;
	
	public ArrayList<Integer>validatePatientid()throws PatientException;

}
