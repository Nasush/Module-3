package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.util.DBUtil;

public class PatientDao implements IPatientDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger patLogger=null;
	public PatientDao()
	{
		PropertyConfigurator.configure("resource/log4j.properties");
		patLogger=Logger.getLogger("PatientDao.class");
	}
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException 
	{
		String insertQry="INSERT INTO Patient"
				+ "(patient_id,patient_name,age,phone,description,consultation_date)"
				+ "VALUES(?,?,?,?,?,sysdate)";
		int dataAdded=generatePatientId();
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, dataAdded);
			pst.setString(2, patient.getPatientName());
			pst.setInt(3, patient.getAge());
			pst.setString(4, patient.getPhoneNo());
			pst.setString(5, patient.getDescription());
			pst.executeUpdate();
			patLogger.log(Level.INFO,
					"patient details Inserted:"+patient);
			} 
		catch (Exception e)
		{
			
			throw new PatientException (e.getMessage());	
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (Exception e) 
			{
				patLogger.error("This is Exception:"+e.getMessage());
				throw new PatientException(e.getMessage());
			}
		}
		return dataAdded;
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientException 
	{
		String selectQry="SELECT * FROM Patient WHERE patient_id=?";
		PatientBean pb=null;
		 try
		    {
		        con=DBUtil.getCon();
		        pst=con.prepareStatement(selectQry);
		        pst.setInt(1, patientId);
		        rs=pst.executeQuery();
		        
		        while(rs.next())
				{
		        pb=new PatientBean(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getDate(6));
				}
		    }
		    catch (Exception e)
		    {
		        throw new PatientException(e.getMessage());
		    }
		    finally
		    {
		        try
		        {
		            pst.close();
		            con.close();
		        }
		        catch (SQLException e)
		        {
		            
		            throw new PatientException(e.getMessage());
		        }
		    }
		    return pb;
			
	}

	@Override
	public int generatePatientId() throws PatientException
	{
		
		String qry="SELECT Patient_Id_Seq.NEXTVAL FROM DUAL";
        int generatedVal;
        try
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(qry);
            rs.next();
            generatedVal=rs.getInt(1);
            
        }
        catch (Exception e)
        {
            throw new PatientException(e.getMessage());
        }
        finally
        {
            try 
            {
                rs.close();
                st.close();
                con.close();
            } 
            catch (SQLException e)
            {
                
                throw new PatientException(e.getMessage());
            }
        }
        return  generatedVal;
        
    
	}

	@Override
	public ArrayList<Integer> validatePatientid() throws PatientException
	{
		ArrayList<Integer> pList=new ArrayList<Integer>();
		String qry="SELECT patient_id from Patient";
		try
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(qry);
            while(rs.next())
			{
            	int pd=rs.getInt("patient_id");
            	pList.add(pd);
			}
	    }
	    catch (Exception e)
	    {
	        throw new PatientException(e.getMessage());
	    }
	    finally
	    {
	        try
	        {
	        	rs.close();
	        	st.close();
	            con.close();
	        }
	        catch (SQLException e)
	        {
	            
	            throw new PatientException(e.getMessage());
	        }
	    }
	    return pList;
	}

}
	


		
	


