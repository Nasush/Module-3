package com.capgemini.tcc.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDao;
import com.capgemini.tcc.dao.PatientDao;
import com.capgemini.tcc.exception.PatientException;


public class PatientService implements IPatientService
{
IPatientDao IDao=null;
public PatientService()
{
	IDao=new PatientDao();
}
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException 
	{
		
		return IDao.addPatientDetails(patient);
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientException
	{
		
		return IDao.getPatientDetails(patientId);
	}
	@Override
	public int generatePatientId() throws PatientException 
	{
	
		return IDao.generatePatientId();
	}
	@Override
	public boolean validateName(String name) throws PatientException
	{
		{
			String namePattern="[A-Z][a-z]{1,20}";
			if(Pattern.matches(namePattern, name))
			{
				return true;
			}
			else
			{
				throw new PatientException
				("Only chars allowed and starts with capital e.g Sukanya");
			}
			
		}
	}
	@Override
	public boolean validateAge(int age) throws PatientException 
	{
		if(age>18 && age<60)
		{
			return true;
		}
		
		else
			
		{
			System.out.println("Age has to be greater than 18 and less than 60");
			return false;
		}
	
	
	}
	@Override
	public boolean validatePhoneNo(String phoneNo) throws PatientException 
	{
		String phnPattern="[7-9][0-9]{9}";
		
		if(Pattern.matches(phnPattern,phoneNo ))
		{
			return true;
		}
		else
		{
			throw new PatientException("Invalid phone number");
		}
		
	}
	@Override
	public boolean validateDescription(String description)
			throws PatientException 
	{
		String descriptionPattern="[A-Z][a-z]{5,}";
		if(Pattern.matches(descriptionPattern, description))
		{
			return true;
		}
		else
		{
			throw new PatientException
			("The description should have minimum 5 character.");
		}
		
	}
	@Override
	public ArrayList<Integer> validatePatientid() throws PatientException 
	{
		
		return IDao.validatePatientid();
	}
	@Override
	public boolean validatePatientId(int patientId) throws PatientException 
	{
		ArrayList<Integer> patId= IDao.validatePatientid();
		
		for(Integer a:patId)
		{
			if(patientId==a)
			{
				return true;
			}
		}
		return false;
	}
	
}
