package com.capgemini.tcc.service;

import java.util.ArrayList;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;



public interface IPatientService 
{
	public int addPatientDetails(PatientBean patient)throws PatientException;
	public PatientBean getPatientDetails(int patientId)throws PatientException;
	public int generatePatientId()throws PatientException;
	public boolean validateName(String name)throws PatientException;
	public boolean validateAge(int age)throws PatientException;
	public boolean validatePhoneNo(String phoneNo)throws PatientException;
	public boolean validateDescription(String description)throws PatientException;
	public ArrayList<Integer>validatePatientid()throws PatientException;
	public boolean validatePatientId(int patientId)throws PatientException;
	
}
