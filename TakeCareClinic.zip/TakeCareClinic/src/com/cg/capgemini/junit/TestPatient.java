package com.cg.capgemini.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDao;
import com.capgemini.tcc.dao.PatientDao;
import com.capgemini.tcc.exception.PatientException;

public class TestPatient 
{
	static IPatientDao IDao=null;
	static PatientBean patient=null;
	@BeforeClass
	public static void beforeClass() throws PatientException
    {
		IDao=new PatientDao();
		patient=new PatientBean(IDao.generatePatientId(),"Shilpa",22,"8109453231l","Cold", null);
    }
		@Test
	    public void testAddPatient1() throws PatientException
	    {
	        Assert.assertEquals(0,IDao.addPatientDetails(patient));
	    }
	 @Test
		public void testSelect1() throws PatientException
		 {
		   Assert.assertNotNull(IDao.generatePatientId());
		 }
    }

