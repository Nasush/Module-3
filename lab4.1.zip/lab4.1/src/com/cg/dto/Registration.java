package com.cg.dto;

public class Registration
{
    private String fName;
    private String lName;
    private String password;
    private String city;
    private char gender;
    private String skillset;
    
    public String getfName() {
        return fName;
    }
    public void setfName(String fName) {
        this.fName = fName;
    }
    public String getlName() {
        return lName;
    }
    public void setlName(String lName) {
        this.lName = lName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public char getGender() {
        return gender;
    }
    public void setGender(char gender) {
        this.gender = gender;
    }
    public String getSkillset() {
        return skillset;
    }
    public void setSkillset(String skillset) {
        this.skillset = skillset;
    }
    public Registration(String fName, String lName, String password,char gender,
              String skillset,String city) {
        super();
        this.fName = fName;
        this.lName = lName;
        this.password = password;
        this.city = city;
        this.gender = gender;
        this.skillset = skillset;
    }
    public Registration() 
    {
        
    }
    @Override
    public String toString() {
        return "Registration [fName=" + fName + ", lName=" + lName
                + ", password=" + password + ", city=" + city + ", gender="
                + gender + ", skillset=" + skillset + "]";
    }
    
}
