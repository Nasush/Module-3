package com.cg.dao;

import java.sql.SQLException;

import com.cg.dto.Registration;

public interface RegistrationDao 
{
	public int getDetails(Registration register) throws SQLException; 

}
