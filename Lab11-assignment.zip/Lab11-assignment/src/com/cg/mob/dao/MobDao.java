package com.cg.mob.dao;
import java.util.ArrayList;

import com.cg.mob.bean.Mobile;
import com.cg.mob.bean.PurchaseDetails;
import com.cg.mob.exception.MobileException;
public interface MobDao
{

	public int addPurchaseDet(PurchaseDetails pd) 
	throws MobileException;
	public ArrayList<Mobile> getAllMob()throws
	MobileException;
	
	public int generatePurchaseId()
	throws MobileException;
	
	public int deleteDetails(int mobileId)throws
	MobileException;

	public int UpdateQuantity(int mobileId)
	throws MobileException;
	public int searchDetails(float minPrice, float maxPrice)
	throws MobileException;

	
}
