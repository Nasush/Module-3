package com.cg.mob.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mob.bean.Mobile;
import com.cg.mob.bean.PurchaseDetails;
import com.cg.mob.exception.MobileException;
import com.cg.mob.util.DBUtil;

public class MobDaoImpl implements MobDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger mobLogger=null;
	public MobDaoImpl()
	{
		PropertyConfigurator.configure("resource/log4j.properties");
		mobLogger=Logger.getLogger("MobDaoImpl.class");
	}

	@Override
	public int addPurchaseDet(PurchaseDetails pd) throws MobileException
	{
		String insertQry="INSERT INTO purchaseDetails"
				+ "(purchaseid,cname,mailid,phoneno,purchasedate,mobileid)"
				+ "VALUES(?,?,?,?,sysdate,?)";
		int dataAdded=0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			
			pst.setInt(1, pd.getPurchaseId());
			pst.setString(2, pd.getCustName());
			pst.setString(3, pd.getMailId());
			pst.setString(4, pd.getPhoneNo());
			pst.setInt(5, pd.getMobileId());
			
			dataAdded=pst.executeUpdate();
			mobLogger.log(Level.INFO,
					"Mob details Inserted:"+pd);
			
			
		} 
		catch (Exception e)
		{
			
			throw new MobileException (e.getMessage());	
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (Exception e) {
				mobLogger.error("This is Exception:"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return dataAdded;
	}

	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException 
	{
		 ArrayList<Mobile> mobList=new ArrayList<Mobile>();
	        String selectQry="Select * from mobiles ";
	        Mobile ee=null;
	        try
	        {
	            
	            con=DBUtil.getCon();
	            st=con.createStatement();
	            rs=st.executeQuery(selectQry);
	            while(rs.next())
	            {
	                ee=new Mobile
	                (rs.getInt("mobileid"),
							rs.getString("name"),
							rs.getInt("price"),
							rs.getInt("quantity"));
	                mobList.add(ee);
	            }
	        }
	        catch (Exception e)
	        {
	            throw new MobileException(e.getMessage());
	        } 
	        finally
	        {
	            try
	            {
	                rs.close();
	                st.close();
	                con.close();
	            }
	            catch (SQLException e)
	            {
	                
	                throw new MobileException(e.getMessage());
	            }
	        }
	        return mobList;
		
	}

	@Override
	public int UpdateQuantity(int mobileid) throws MobileException
	{
		
			String updateQry="UPDATE MOBILES SET QUANTITY=QUANTITY-1 WHERE MOBILEID=? ";
	        int dataUpdated=0;
	        try
	        {
	            con=DBUtil.getCon();
	            pst=con.prepareStatement(updateQry);
	            pst.setInt(1, mobileid);
	            dataUpdated=pst.executeUpdate();
	            System.out.println("Data updation in DAO:"+dataUpdated);
	            
	        }
	        catch (Exception e)
	        {
	            throw new MobileException(e.getMessage());
	        }
	        finally
	        {
	            try
	            {
	                pst.close();
	                con.close();
	            }
	            catch (SQLException e)
	            {
	                
	                throw new MobileException(e.getMessage());
	            }
	        }
	        return dataUpdated;
	        
	}


	@Override
	public int deleteDetails(int mobileId) throws MobileException 
	{
	
		String deleteQry="Delete from mobiles where mobileid=?";
        int dataDeleted=0;
        try
        {
            con=DBUtil.getCon();
            pst=con.prepareStatement(deleteQry);
            pst.setInt(1, mobileId);
            dataDeleted=pst.executeUpdate();
            System.out.println("Data deletion in DAO:"+dataDeleted);
            
        }
        catch (Exception e)
        {
            throw new MobileException(e.getMessage());
        }
        finally
        {
            try
            {
                pst.close();
                con.close();
            }
            catch (SQLException e)
            {
                
                throw new MobileException(e.getMessage());
            }
        }
        return dataDeleted;
        
    }

	@Override
	public int generatePurchaseId() throws MobileException
	{
		
		String qry="SELECT pd_seq.NEXTVAL FROM DUAL";
        int generatedVal;
        try
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(qry);
            rs.next();
            generatedVal=rs.getInt(1);
            
        }
        catch (Exception e)
        {
            throw new MobileException(e.getMessage());
        }
        finally
        {
            try 
            {
                rs.close();
                st.close();
                con.close();
            } 
            catch (SQLException e)
            {
                
                throw new MobileException(e.getMessage());
            }
        }
        return  generatedVal;
        
    
	}



@Override
public int searchDetails(float minPrice, float maxPrice) throws MobileException {
	String selectQry="SELECT PRICE FROM MOBILES WHERE PRICE BETWEEN"
	 		+ "? AND ?";
	 int dataRange=0;
    try
    {
        con=DBUtil.getCon();
        pst=con.prepareStatement(selectQry);
        pst.setFloat(1, minPrice);
        pst.setFloat(2, maxPrice);
        dataRange=pst.executeUpdate();
        System.out.println("Search mobiles:"+dataRange);
        
    }
    catch (Exception e)
    {
        throw new MobileException(e.getMessage());
    }
    finally
    {
        try
        {
            pst.close();
            con.close();
        }
        catch (SQLException e)
        {
            
            throw new MobileException(e.getMessage());
        }
    }
    return dataRange;
	
}




	}

	
	
	


	

