package com.cg.mob.service;

import java.util.ArrayList;
import java.util.regex.Pattern;





import com.cg.mob.bean.Mobile;
import com.cg.mob.bean.PurchaseDetails;
import com.cg.mob.dao.MobDao;
import com.cg.mob.dao.MobDaoImpl;
import com.cg.mob.exception.MobileException;


public  class MobileServiceImpl implements MobileService
{
	MobDao mob=null;
	public MobileServiceImpl()
	{
		mob=new MobDaoImpl();
	}

	@Override
	public int addPurchaseDet(PurchaseDetails pd) throws MobileException 
	{
		
		return mob.addPurchaseDet(pd);
	}

	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException {
		
		return mob.getAllMob();
	}

	@Override
	public boolean validateName(String custName) throws MobileException
	{
	
		{
			String namePattern="[A-Z][a-z]+{20}";
			if(Pattern.matches(namePattern, custName))
			{
				return true;
			}
			else
			{
				throw new MobileException
				("Only chars allowed and starts with capital e.g Sukanya");
			}
			
		}
	}


	@Override
	public boolean validateDigit1(int mobileId) throws MobileException {
		{
			String numPattern="[0-9]{4}";
			if(Pattern.matches(numPattern, new Integer(mobileId).toString()))
			{
				return true;
			}
			else
			{
		throw new MobileException
		("Only min 4 digits allowed in mobile id and should be present in mobile table");
		}
		}
	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		
		return mob.generatePurchaseId();
	}

	@Override
	public boolean validateDigit(String phoneNo) throws MobileException 
	{
		String numPattern="[7-9]{1}[0-9]{9}";
		if(Pattern.matches(numPattern, new Long(phoneNo).toString()))
		{
			return true;
		}
		else
			
		{
			throw new MobileException("Mobile number should contains 10 digit");
		}
	
	}

	@Override
	public boolean validatemail(String mailId) throws MobileException 
	{
		

		{
			String namePattern="[a-z0-9]+[@]+[a-z]+[/.]+[a-z]+";
			if(Pattern.matches(namePattern, mailId))
			{
				return true;
			}
			else
			{
				throw new MobileException
				("Enter valid mail id eg:sukanya22@yahoo.com");
			}
			
		}
	}

	
	public boolean validateQuantity(int quantity) throws MobileException 
	{
		
		if(quantity>0)
		{
			return true;
		}
		else
			
		{
			throw new MobileException("Quantity should be greater than 0");
		}
	
	}

	@Override
	public int deleteDetails(int mobileId) throws MobileException {
		
		return mob.deleteDetails(mobileId);
	}

	@Override
	public int UpdateQuantity(int mobileId) throws MobileException {
	return mob.UpdateQuantity(mobileId);
	}

	@Override
	public int searchDetails(float minPrice, float maxPrice)
			throws MobileException {
		
		return mob.searchDetails(minPrice, maxPrice);
	}

	
}
