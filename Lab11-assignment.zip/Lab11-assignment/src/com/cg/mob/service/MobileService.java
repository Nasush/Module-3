package com.cg.mob.service;

import java.util.ArrayList;

import com.cg.mob.bean.Mobile;
import com.cg.mob.bean.PurchaseDetails;
import com.cg.mob.exception.MobileException;
public interface MobileService 
{
	public int addPurchaseDet(PurchaseDetails pd)//service sends 
			throws MobileException;
	
			public ArrayList<Mobile> getAllMob()throws
			MobileException;
			//add emp details to arraylist
			
			
			public boolean validateName(String custName)
			throws MobileException;
			
			public boolean validatemail(String mailId)
					throws MobileException;
			
			public boolean validateDigit(String phoneno)
					throws MobileException;
			
			public boolean validateDigit1(int mobileId)
					throws MobileException;
			
			public int generatePurchaseId()throws
			MobileException;

			public boolean validateQuantity(int quantity)
					throws MobileException ;

			public int deleteDetails(int mobileId) throws 
			MobileException;

			public int UpdateQuantity(int mobileId)
			throws MobileException;

			public int searchDetails(float minPrice, float maxPrice)
			throws MobileException;
			
			
			
		

}
