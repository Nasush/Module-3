 package com.cg.mob.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mob.bean.Mobile;
import com.cg.mob.bean.PurchaseDetails;
import com.cg.mob.exception.MobileException;
import com.cg.mob.service.MobileService;
import com.cg.mob.service.MobileServiceImpl;

public class MobileClient 
{
    static Scanner sc=null;
    static MobileService mobSer=null;
    public static void main(String[] args)
    {
        mobSer=new MobileServiceImpl();
        sc=new Scanner(System.in);
        int choice=0;
        while(true)
        {
             System.out.println("What do u want to Do?");
                System.out.println("1:Insert Customer\t" +"2:Update quantity\t"
                        +"3:View Mob Details\t" +"4:Delete mob details\t"
                        		+ "5:search mobile based on range"+ "6:exit");
                choice=sc.nextInt();
                switch(choice)
                {
                case 1: insertCustomer();
                break;
               /* case 2: UpdateQuantity();
                break;*/
                case 3: viewDetails();
                break;
                case 4:	deleteDetails();
                break;
                case 5: searchDetails();
                 break;
                
                default: System.exit(0);
                }       
            }
        }

    
 private static void searchDetails() 
 {
	 {
		 	System.out.println("Enter minimum price");
			float minPrice=sc.nextFloat();
			System.out.println("Enter maximum price");
			float maxPrice=sc.nextFloat();
			
			try
			{
			int searchData=mobSer.searchDetails(minPrice,maxPrice);
			System.out.println(searchData);
			if(searchData==1)
			{
				System.out.println("mobile searched based on price range");
			}
			
	        else
	        {
	        	System.out.println("May some exception occurs");
	        }
			}
			 catch (MobileException e)
	         {

	             System.out.println(e.getMessage());
	         }
	 }
		
	}


private static void deleteDetails() 
		{
	 	System.out.println("Enter Mobile id");
		int mobileId=sc.nextInt();
		try
		{
		int dataDeleted=mobSer.deleteDetails(mobileId);
		System.out.println(dataDeleted);
		if(dataDeleted==1)
		{
			System.out.println("mobile data deleted");
		}
		
        else
        {
        	System.out.println("May some exception occurs");
        }
		}
		 catch (MobileException e)
         {

             System.out.println(e.getMessage());
         }
		
	}


/******************************************************/   
private static void UpdateQuantity(int mobileid) 
	{
	//System.out.println("Enter Mobile id");
	//int mobileId=sc.nextInt();
	try
	{
	int dataUpdated=mobSer.UpdateQuantity(mobileid);
	System.out.println(dataUpdated);
	if(dataUpdated==1)
	{
		System.out.println("mobile data updated");
	}
	
    else
    {
    	System.out.println("May some exception occurs");
    }
	}
	 catch (MobileException e)
     {

         System.out.println(e.getMessage());
     }
	
}

/******************************************************/
private static void viewDetails() {

    try{
        ArrayList<Mobile> mobList=mobSer.getAllMob();
        for(Mobile mob:mobList)
        {
            System.out.println(mob);
        }
    }
    catch(MobileException e)
    {
        System.out.println("SomeException");
    }
		
	}

/******************************************************/
    public static void insertCustomer()
    {
        System.out.println("Enter Customer Name:");
        String cName=sc.next();
            
        try
        {
            if(mobSer.validateName(cName))
                {
                    System.out.println("Enter email  Id: ");
                    String mailid=sc.next();
                    if(mobSer.validatemail(mailid))
                    {
                        System.out.println("Enter phone number: ");
                        String phoneno=sc.next();
                        if(mobSer.validateDigit(phoneno))
                        {
                        	System.out.println("Enter Quantity: ");
                            int quantity=sc.nextInt();
                            if(mobSer.validateQuantity(quantity))
                            {
                        	
                            System.out.println("Enter MobileId number: ");
                            int mobileid=sc.nextInt();
                            
                            if(mobSer. validateDigit1(mobileid))
                            {
                            	PurchaseDetails pd=new PurchaseDetails();
                                pd.setMobileId(mobileid);
                                pd.setCustName(cName);
                                pd.setMailId(mailid);
                                pd.setPhoneNo(phoneno);
                               
                                int dataAdded=mobSer.addPurchaseDet(pd);
                                if(dataAdded==1)
                                {
                                	 System.out.println("Mobile data added");
                                	 UpdateQuantity(mobileid);
                                }
                                else
                                {
                                	System.out.println("May some exception occurs");
                                	
                                }
                            }
                        }
                    }
                    
                    
                }
            }
        }
            catch (MobileException e)
            {

                System.out.println(e.getMessage());
            }

       
    }
   
    }
/************************************************************/
    

   