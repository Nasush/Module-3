
package com.cg.mob.junit;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mob.bean.Mobile;
import com.cg.mob.bean.PurchaseDetails;
import com.cg.mob.dao.MobDao;
import com.cg.mob.dao.MobDaoImpl;
import com.cg.mob.exception.MobileException;


public class mobileDaoImplTest
{
    static Mobile mob=null;
    static MobDao mobdao=null;
    static PurchaseDetails pd=null;
    
    @BeforeClass
    public static void beforeClass() throws MobileException
    {
        long millis=System.currentTimeMillis();  
        java.sql.Date dates=new java.sql.Date(millis);
        mobdao=new MobDaoImpl();
        mob=new Mobile(1001,"Nokia Lumia 520",8000,2);
        pd=new PurchaseDetails(mobdao.generatePurchaseId(),"Sukanya",
                "sukanyasuvarna@gmail.com","9886329921",0,0);
    }
    
    @Test
    public void testAddPur() throws MobileException
    {
        Assert.assertEquals(1, mobdao.addPurchaseDet(pd));
    }

}
