package com.cg.admin.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.UserException;
import com.cg.admin.service.FlightInfoService;
import com.cg.admin.service.FlightInfoServiceImpl;
import com.cg.admin.service.UsersService;
import com.cg.admin.service.UsersServiceImpl;

public class AdminClient 
{
	static Scanner sc=null;
	static FlightInfoService fSer=null;
	static UsersService uSer=new UsersServiceImpl();
	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws NumberFormatException, IOException, UserException 
	{
		sc=new Scanner(System.in);
		fSer=new FlightInfoServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("********************");
			System.out.println("Select an Operation");
			System.out.println("1:Enter Details\n"
					+ "2:View Details based on Applicant Id\n"
					+ "0:Exit");
			System.out.println("********************");
			System.out.println("Please Enter a choice");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:insertFlightInfo();
			break;
			case 2:viewFlightInfo();
			break;
			case 3:Login();
			break;
			default:
				System.out.println("Invalid Input");
				System.exit(0);

			}
	}
}
	public static void insertFlightInfo() throws NumberFormatException, IOException
	{
		try
		{
			System.out.println("**************WELCOME ADMIN***************");
			System.out.println("************Create Flights************");
			System.out.println("Enter Flight No:");
			int fNo=Integer.parseInt(br.readLine());
			System.out.println("Enter Airways Name:");
			String airways = br.readLine();
			System.out.println("Enter City of departure: ");
			String deptCity = br.readLine();
			System.out.println("Enter Destination City: ");
			String arrCity = br.readLine();
			System.out.println("Enter Date of Departure (dd/mm/yyyy):");
			String deptDate = br.readLine();
			DateTimeFormatter dtf =  DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate DepartureDate = LocalDate.parse(deptDate, dtf);
			System.out.println("Enter Date of Arrival (dd/mm/yyyy):");
			String arrDate = br.readLine();
		    LocalDate ArrivalDate = LocalDate.parse(arrDate, dtf);
			System.out.println("Enter depart time (in 24 hr format): ");
			String deptTime = br.readLine();
			System.out.println("Enter Arrival Estimated time (in 24 hr format): ");
			String arrtTime = br.readLine();
			System.out.println("Enter the number of Economy class Seats :");
			int firstSeats = Integer.parseInt(br.readLine());
			int firstSeatsAvail = firstSeats;
			System.out.println("Enter the Economy class seat fare per seat: ");
			float firstSeatsFare = Float.parseFloat(br.readLine());
			System.out.println("Enter the number of Business Class Seats :");
			int bussSeats = Integer.parseInt(br.readLine());
			int bussSeatsAvail = bussSeats;
			System.out.println("Enter the Business class seat fare per seat: ");
			float bussSeatsFare = Float.parseFloat(br.readLine());
			FlightInformation aft = new FlightInformation(fNo,airways,deptCity,arrCity,
			DepartureDate,ArrivalDate,deptTime,arrtTime,firstSeats,firstSeatsFare,bussSeats,bussSeatsFare,firstSeatsAvail,bussSeatsAvail);
			fSer.insertFlightInformation(aft);
			System.out.println("Flight inserted successfully");
			
		
		}
		catch(AdminException e)
		{
			System.out.println(e.getMessage());
		}
	}
	public static void viewFlightInfo()
	{
		
	}
	public static void Login() throws IOException, UserException
	{
	System.out.println("************Login*************");
	while(true)
	{
		System.out.println("Enter User Name:");
		String username = br.readLine();
		System.out.println("Enter Password:");
		String password = br.readLine();
		 boolean isValid=uSer.fetchParticularUser(username, password);
		 if(isValid)
		 {
			 int isValidRole=uSer.fetchRole(username, password);
			 switch(isValidRole)
			 {
			 case 1:insertFlightInfo();
				 break;
			 case 2:System.out.println("::::::::WELCOME EXECUTIVE:::::::::");
				 break;
			 }
		 }
	}
	}
}
