package com.cg.admin.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;



import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.util.DBUtil;




public class FlightInfoDaoImpl implements FlightInfoDao
{
	Connection conn;
	@Override
	public int insertFlightInformation(FlightInformation fi)
			throws AdminException 
	{
		int dataAdded;
		PreparedStatement pst;
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.INSERT_FLIGHT_INFORMATION);
			pst.setInt(1,fi.getFlightNo());
			pst.setString(2, fi.getAirline());
			pst.setString(3, fi.getDeptCity());
			pst.setString(4, fi.getArrCity());
			
			pst.setDate(5, Date.valueOf(fi.getDeptDate()));
			pst.setDate(6, Date.valueOf(fi.getArrDate()));
			pst.setString(7, fi.getDeptTime());
			pst.setString(8, fi.getArrTime());
			pst.setInt(9,fi.getFirstSeats());
			pst.setDouble(10, fi.getFirstSeatsFare());
			pst.setInt(11, fi.getBussSeats());
			pst.setDouble(12, fi.getBussSeatsFare());
			pst.setInt(13, fi.getAvlFirstSeats());
			pst.setInt(14, fi.getAvlBussSeats());
			
			dataAdded=pst.executeUpdate();
		}
		catch (Exception e) 
		{
			throw new AdminException("Problem in inserting Flight Details"+e.getMessage());
			
		} 
		
		
		
		return dataAdded;
	}

	@Override
	public int updateFlightInformation(int flightNo) throws AdminException 
	{
		
		return 0;
	}

	@Override
	public FlightInformation getFlightList(FlightInformation fi)
			throws AdminException 
	{
		
		return null;
	}

	@Override
	public int countBookingIds(int flightNo) throws AdminException 
	{
		
		return 0;
	}

}
