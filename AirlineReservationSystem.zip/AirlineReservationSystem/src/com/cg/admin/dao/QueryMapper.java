package com.cg.admin.dao;

public interface QueryMapper 
{
	String INSERT_USER="INSERT INTO users values(?,?,?,?)";
	String CHECK_USERNAME="SELECT username FROM users WHERE password=?";
	String CHECK_ROLE="SELECT role FROM users WHERE username=? AND password=?";
	String SEQUENCE_FLIGHT_NO="SELECT flt_no_seq.NEXTVAL FROM DUAL";
	String SEQUENCE_BOOKING_ID="SELECT book_id_seq.NEXTVAL FROM DUAL";
	String INSERT_FLIGHT_INFORMATION="INSERT INTO flightInformation values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String SELECT_ALL_FLIGHTS="SELECT * FROM flightInformation";
	String UPDATE_ARR_TIME="UPDATE flightInformation set arrTime=? WHERE flightNo=?";
	String UPDATE_DEPT_TIME="UPDATE flightInformation set deptTime=? WHERE flightNo=?";
	String UPDATE_FIRST_FARES="UPDATE flightInformation set firstSeatsFares=? WHERE flightNo=?";
	String UPDATE_BUSS_FARES="UPDATE flightInformation set bussSeatsFares=? WHERE flightNo=?";
	String UPDATE_ARR_CITY="UPDATE flightInformation set arrCity=? WHERE flightNo=?";
	String UPDATE_DEPT_CITY="UPDATE flightInformation set deptCity=? WHERE flightNo=?";
	String BOOKINGS_FOR_SPECIFIC_FLIGHT="SELECT count(bookingId) FROM bookingInformation where flightNo=? group by flightNo";
	String SELECT_PASSGR_DET_FOR_SPECIFIC_FLT="SELECT * FROM bookingInformation where flightNo=?";
	String SELECT_FLIGHT_PAR_DAY_PAR_CITY="SELECT * FROM flightInformation where arrCity=? AND arrDate=?";
	String SELECT_FLIGHT_PAR_DAY_PAR_CITY1="SELECT * FROM flightInformation where deptCity=? AND deptDate=?";
	String UPDATE_FLIGHT_INFO="UPDATE flightInformation set airline=?, deptCity=?, arrCity=?, deptDate=?,"
			+ " arrDate=?, deptTime=?, arrTime=?, firstSeats=? firstSeatsFares=?, bussSeats=?, bussSeatsFares=? where flightNo=?";
	
	

}
