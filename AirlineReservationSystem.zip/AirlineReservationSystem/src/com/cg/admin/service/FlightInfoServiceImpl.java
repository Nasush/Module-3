package com.cg.admin.service;

import com.cg.admin.dao.FlightInfoDao;
import com.cg.admin.dao.FlightInfoDaoImpl;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;

public class FlightInfoServiceImpl implements FlightInfoService {

	FlightInfoDao fDao=new FlightInfoDaoImpl();
	@Override
	public int insertFlightInformation(FlightInformation fi)
			throws AdminException {
		
		return fDao.insertFlightInformation(fi);
	}

	@Override
	public int updateFlightInformation(int flightNo) throws AdminException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public FlightInformation getFlightList(FlightInformation fi)
			throws AdminException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int countBookingIds(int flightNo) throws AdminException {
		// TODO Auto-generated method stub
		return 0;
	}

}
