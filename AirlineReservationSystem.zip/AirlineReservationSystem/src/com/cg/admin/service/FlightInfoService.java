package com.cg.admin.service;

import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;

public interface FlightInfoService 
{
	int insertFlightInformation(FlightInformation fi)throws AdminException;
    int updateFlightInformation(int flightNo)throws AdminException;
    FlightInformation getFlightList(FlightInformation fi)throws AdminException;
    int countBookingIds(int flightNo)throws AdminException;

}
