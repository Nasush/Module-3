package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.service.RegistrationService;
import com.cg.service.RegistrationServiceImpl;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	RegistrationService reg=null;
	private static final long serialVersionUID = 1L;
  
    public RegistrationServlet()
    {
        super();
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter pw=response.getWriter();
		reg=new RegistrationServiceImpl();
		String fnm=request.getParameter("fName");
		String lnm=request.getParameter("lName");
		String pas=request.getParameter("pwd");
		String gen=request.getParameter("gender");
		String skill=request.getParameter("name");
		String cit=request.getParameter("list");
		try
		{
		
		}
	}

}

