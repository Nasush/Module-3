package com.cg.dao;

import java.sql.SQLException;
import com.cg.dto.Registration;

public interface RegistrationDao 
{
	public Registration getRegistrationDetails(Registration register)
			throws SQLException;
}
