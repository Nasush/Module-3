package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.dto.Registration;
import com.cg.util.DBUtil;

public class RegistrationDaoImpl implements RegistrationDao
{

	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public Registration getRegistrationDetails(Registration register)
			throws SQLException 
	{
		Registration user=null;
		con=DBUtil.getCon();
		System.out.println("Got Connection :");
		String insertQry="INSERT INTO RegisteredUsers"
				+ "(firstname,lastname,password,gender,skillset,city)"
				+ "VALUES(?,?,?,?,?,?)";
		pst=con.prepareStatement(insertQry);
		pst.setString(1, register.getFirstName());
		pst.setString(2, register.getLastName());
		pst.setString(3, register.getPassword());
		pst.setString(4, register.getGender());
		pst.setString(5, register.getSkillset());
		pst.setString(6, register.getCity());
		
		rs=pst.executeQuery();
		rs.next();
		user=new Registration(
		rs.getString("firstname"),
		rs.getString("lastname"),
		rs.getString("password"),
		rs.getString("gender"),
		rs.getString("skillset"),
		rs.getString("city"));
	return user;
	}

}
