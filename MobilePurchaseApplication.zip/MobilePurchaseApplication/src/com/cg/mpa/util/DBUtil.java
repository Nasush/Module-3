package com.cg.mpa.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.mpa.exception.MobileException;

public class DBUtil 
{
	public static Connection getConnection() throws MobileException
	{
		Connection con=null;
		InitialContext context;
		try
		{
			context=new InitialContext();
			DataSource ds=(DataSource)
					context.lookup("java:/jdbc/OracleDS");
					con=ds.getConnection();
		}
		catch(NamingException e)
		{
			throw new MobileException("Problem in obtaining Datasource:"+e.getMessage());
		}catch(SQLException e)
		{
			throw new MobileException("Problem in obtaining Connection from Datasource"+e.getMessage());
		}
		return con;
	}
}
