package com.cg.mpa.dto;

public class Mobile 
{
	private long mobileId;
	private String mname;
	private double price;
	private int quantity;

	public long getMobileId()
	{
		return mobileId;
	}
	public void setMobileId(long mobileId) {
		this.mobileId = mobileId;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Mobile() 
	{
		super();
		
	}
	public Mobile(long mobileId, String mname, double price, int quantity) {
		super();
		this.mobileId = mobileId;
		this.mname = mname;
		this.price = price;
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mname=" + mname + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
	
	
	
	
}
