package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurchaseDetails 

{
	private long purchaseid;
	private String cname;
	private String mailId;
	private long phoneNo;
	private LocalDate purchaseDate;
	private long mobileId;
	public long getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(long purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public long getMobileId() {
		return mobileId;
	}
	public void setMobileId(long mobileId) {
		this.mobileId = mobileId;
	}
	public PurchaseDetails(long purchaseid, String cname, String mailId,
			long phoneNo, LocalDate purchaseDate, long mobileId) {
		super();
		this.purchaseid = purchaseid;
		this.cname = cname;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
	public PurchaseDetails() {
		super();
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseid=" + purchaseid + ", cname=" + cname
				+ ", mailId=" + mailId + ", phoneNo=" + phoneNo
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}
	
	
	
}
