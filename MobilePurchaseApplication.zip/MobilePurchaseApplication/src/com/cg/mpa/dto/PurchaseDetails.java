package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurchaseDetails 
{
	private long purchaseId;
	private String cname;
	private String mailId;
	private long phoneno;
	private LocalDate purchaseDate;
	private long mobileId;// select * from purchasedetails;
	
	public long getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(long purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public long getMobileId() {
		return mobileId;
	}
	public void setMobileId(long mobileId) {
		this.mobileId = mobileId;
	}
	public PurchaseDetails() 
	{
		
	}
	public PurchaseDetails(long purchaseId, String cname, String mailId,
			long phoneno, LocalDate purchaseDate, long mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.cname = cname;
		this.mailId = mailId;
		this.phoneno = phoneno;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", cname=" + cname
				+ ", mailId=" + mailId + ", phoneno=" + phoneno
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}
	
}
