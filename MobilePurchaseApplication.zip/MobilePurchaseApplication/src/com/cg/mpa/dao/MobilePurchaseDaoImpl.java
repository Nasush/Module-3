package com.cg.mpa.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao 
{ Connection conn;


	@Override
	public List<Mobile> getAllMobiles() throws MobileException
	{
		List<Mobile> mList=new ArrayList<>();
		try
		{
		conn=DBUtil.getCon();
		Statement st=conn.createStatement();
		ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
		while(rst.next())
		{
			Mobile m=new Mobile();
			m.setMobileId(rst.getLong("mobileId"));
			m.setmName(rst.getString("name"));
			m.setPrice(rst.getDouble("price"));
			m.setQuantity(rst.getInt("quantity"));
			mList.add(m);
			
			}
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in fetching the"
					+ " mobile list"+e.getMessage());
			
		}
		

		return mList;
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException
	{
		try {
			conn=DBUtil.getCon();
			Mobile m=null;
			PreparedStatement pst=conn.prepareCall(QueryMapper.SELECT_MOBILE);
			pst.setLong(1,mid);
			ResultSet rst = pst.executeQuery();
			if(rst.next())
			{
				m=new Mobile();
				m.setMobileId(rst.getLong("mobileId"));
				m.setmName(rst.getString("name"));
				m.setPrice(rst.getDouble("price"));
				m.setQuantity(rst.getInt("quantity"));
			}
			else
			{
				throw new MobileException("Mobile not found:" );
			}
			return m;	
		} 
		
		catch (SQLException e) 
		{
			throw new MobileException("Problem in fetching:" +e.getMessage());
		}
	
		
		
	}
	private long generatePurchaseId() throws MobileException
	{
		long pid=0;
	
		try {
			conn=DBUtil.getCon();
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rst.next();
			pid =rst.getLong(1);
		
			
		}
		catch (SQLException e)
		{
			throw new MobileException
			("Problem in generating purchaseId: " +e.getMessage());
		}
		return pid;
		
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException
	{
		
		pDetails.setPurchaseid(generatePurchaseId());
		try
		{
			conn=DBUtil.getCon();
			PreparedStatement pst= 
					conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1, pDetails.getPurchaseid());
			pst.setString(2, pDetails.getCname());
			pst.setString(3, pDetails.getMailId());
			pst.setLong(4, pDetails.getPhoneNo());
			pst.setDate(5, Date.valueOf(
					pDetails.getPurchaseDate()));
			pst.setLong(6, pDetails.getMobileId());
			pst.executeUpdate();
			
		}
		catch (SQLException e)
		{
			throw new MobileException
			("Problem in generating purchaseId: " +e.getMessage());
		}
		return pDetails.getPurchaseid();
	}

}
