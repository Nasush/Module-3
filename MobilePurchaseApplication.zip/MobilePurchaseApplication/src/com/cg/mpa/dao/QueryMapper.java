package com.cg.mpa.dao;

public interface QueryMapper
{
	String SELECT_ALL_MOBILES="select mobileid,name,price,quantity from mobiles";
	String SELECT_MOBILE="select mobileid,name,price,quantity from mobiles where mobileid=?";
	String SELECT_SEQUENCE="select purchase_seq.NEXTVAL FROM dual";
	String INSERT_QUERY="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
	String UPDATE_QUERY="UPDATE MOBILES SET QUANTITY=QUANTITY-1 WHERE MOBILEID=?";
	
}
