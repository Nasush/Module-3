package com.cg.mpa.dao;

public interface QueryMapper 
{

String  SELECT_ALL_MOBILES="SELECT mobileid,name,price,quantity "
		+ "FROM mobiles";

String SELECT_MOBILE="SELECT mobileid,name,price,quantity "
		+ "FROM mobiles where mobileid=?";

String SELECT_SEQUENCE="Select purchase_seq.NEXTVAL FROM dual";

String INSERT_QUERY="INSERT INTO purchasedetails"
		+ " values(?,?,?,?,?,?)";

}
