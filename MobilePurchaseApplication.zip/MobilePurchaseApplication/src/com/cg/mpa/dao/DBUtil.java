package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.mpa.exception.MobileException;







public class DBUtil 
{
	public static Connection getCon() throws SQLException, MobileException
	{
		Connection conn = null;
		InitialContext context;
		try 
		{
			context = new InitialContext();
			DataSource ds = (DataSource)
					context.lookup("java:/jdbc/OracleDS");
			conn=ds.getConnection();
		} 
		catch (NamingException e) 
		{
			
			throw new MobileException("Problem in Obtaining Database" +e.getMessage());
		}
		catch (SQLException e) 
		{
			
			throw new MobileException("Problem in Obtaining Connection" +e.getMessage());
		}
		
	return conn;
	}
	
}
