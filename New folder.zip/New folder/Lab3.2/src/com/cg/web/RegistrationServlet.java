package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Registration;
import com.cg.service.RegistrationService;
import com.cg.service.RegistrationServiceImpl;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	RegistrationService regSer=null;
	private static final long serialVersionUID = 1L;
  
    public RegistrationServlet()
    {
        super();
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		
		regSer=new RegistrationServiceImpl();
		Registration reg=null;
		
		String fNm=request.getParameter("fName");
		String lNm=request.getParameter("lName");
		String pwd=request.getParameter("pwd");
		char gen=request.getParameter("gender").charAt(0);
		String[] sklstr=request.getParameterValues("name");
		String cty=request.getParameter("city");
		int n=sklstr.length;
		String skil=sklstr[0];
		if(n==1)
		{
			skil=sklstr[0];
		}
		else
		{
			while(n>1)
			{
				skil=skil+sklstr[n-1];
				n=n-1;
			}
		}
		reg=new Registration(fNm,lNm,pwd,gen,skil,cty);
		try
		{
			int dataAdded=0;
			dataAdded=regSer.getRegistrationDetails(reg);
			System.out.println("Data Added= "+dataAdded);
			PrintWriter pw=response.getWriter();
			if(dataAdded ==1)
			{
				response.sendRedirect("htmls/Success.html");
			}
			else
			{
				response.sendRedirect("htmls/Failure.html");
			}
		
		
	}

		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
}


		
	



