package com.cg.dao;

import java.sql.SQLException;
import com.cg.dto.Registration;

public interface RegistrationDao 
{
	public int getRegistrationDetails(Registration register)
			throws SQLException;
}
