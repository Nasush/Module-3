package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.dto.Registration;
import com.cg.util.DBUtil;

public class RegistrationDaoImpl implements RegistrationDao
{

	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public int getRegistrationDetails(Registration register)
			throws SQLException 
	{
		Registration user=null;
		con=DBUtil.getCon();
		System.out.println("Got Connection :");
		String insertQry="INSERT INTO RegisteredUsers"
				+ "(firstname,lastname,password,gender,skillset,city)"
				+ "VALUES(?,?,?,?,?,?)";
		pst=con.prepareStatement(insertQry);
		
		String fNm=register.getFirstName();
		String lNm=register.getLastName();
		String pwd=register.getPassword();
		char gen=register.getGender();
		String skil=register.getSkillset();
		String cty=register.getCity();
	
		pst.setString(1,fNm);
		pst.setString(2,lNm);
		pst.setString(3,pwd);
		pst.setString(4,String.valueOf(gen));
		pst.setString(5,skil);
		pst.setString(6,cty);
		
		return pst.executeUpdate();
	}
		
	}


