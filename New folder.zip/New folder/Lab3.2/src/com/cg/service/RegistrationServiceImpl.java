package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.RegistrationDao;
import com.cg.dao.RegistrationDaoImpl;
import com.cg.dto.Registration;

public class RegistrationServiceImpl implements RegistrationService
{
	RegistrationDao reg=null;
	public RegistrationServiceImpl()
	{
		reg=new RegistrationDaoImpl();
	}
	@Override
	public int getRegistrationDetails(Registration register)
			throws SQLException
	{
		
		return reg.getRegistrationDetails(register);
	}

}
