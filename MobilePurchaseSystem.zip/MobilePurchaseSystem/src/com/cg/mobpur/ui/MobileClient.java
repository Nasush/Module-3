package com.cg.mobpur.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobpur.bean.Mobiles;
import com.cg.mobpur.bean.PurchaseDetails;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.service.MobileService;
import com.cg.mobpur.service.MobileServiceImpl;
import com.cg.mobpur.service.PurchaseDetailsService;
import com.cg.mobpur.service.PurchaseDetailsServiceImpl;


public class MobileClient 
{
	static Scanner sc=null;
	static MobileService mobser=null;
	static PurchaseDetailsService purser=null;
	public static void main(String[] args) 
	{
		sc=new Scanner(System.in);
		mobser=new MobileServiceImpl();
		purser=new PurchaseDetailsServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("WHAT DO U WANT TO DO?");
			System.out.println("1:Add Purchase Details and Update Quantity\t"
					+ "2:Fetch All Mobiles\t"
					+ "3:Delete Mobile\t"
					+ "4:Search Appropriate Mobile\t"
					+ "5:Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:insertMobilePurchase();
			break;
			case 2:fetchAllMobiles();
			break;
			case 3:deleteMobile();
			break;
			case 4:searchMobile();
			break;

			default:System.exit(0);
			}

		}

	}
	/**********************main ends here******************************/
	public static void insertMobilePurchase()
	{
		try
		{
			System.out.println("Enter Mobile Id:");
			int mobileId=sc.nextInt();
			if(mobser.validateDigit(mobileId))
			{
				Mobiles mob=new Mobiles();
				mob.setMobileId(mobileId);
				if(mobser.getMobileQuantity(mob)>0)
				{
					System.out.println("Enter Customer Name:");
					String cname=sc.next();
					if(purser.validateName(cname))
					{
						System.out.println("Enter Customer mailID:");
						String mailId=sc.next();
						if(purser.validateMailId(mailId))
						{
							System.out.println("Enter Customer Phone Number:");
							Long phoneNo=sc.nextLong();	
							if(purser.validatePhoneNo(phoneNo))
							{

								System.out.println("Enter Mobile Quantity to be purchased:");
								int quantity=sc.nextInt();
								mob.setQuantity(quantity);
								if(quantity>0)
								{
									if(mobser.updateMobileQty(mob)==1)	
									{
										PurchaseDetails pd=new PurchaseDetails();
										pd.setCustomerName(cname);
										pd.setMailId(mailId);
										pd.setPhoneNo(phoneNo);
										pd.setMobileId(mobileId);
										int dataAdded=purser.insertCustomer(pd);
										if(dataAdded==1)
										{
											System.out.println("Emp data Added:");

										}
										else
										{
											System.out.println("Maybe some exception while Addition");	
										}
										System.out.println("Customer  data Updated:");
									}
									else
									{
										System.out.println("Maybe some exception while Updation");
									}
								}
							}
						}
					}

				}
			}
		}
		catch(MobileException e) 
		{
			System.out.println(e.getMessage());
		}
	}




	public static void fetchAllMobiles()
	{
		try {
			ArrayList<Mobiles> mobList=mobser.getAllMobiles();
			for(Mobiles mob:mobList)
			{
				System.out.println(mob);
			}
		} 
		catch (MobileException e) 
		{
			System.out.println("Maybe some exception while Fetching");
			e.printStackTrace();
		}
	}


	public static void deleteMobile()
	{
		System.out.println("Enter Mobile Id:");
		int mobileId=sc.nextInt();
		try
		{
			int dataDel=mobser.deleteMobile(mobileId);
			if(dataDel==1)
			{
				System.out.println("Mobile data Deleted:");
			}
			else
			{
				System.out.println("Maybe some exception while Deletion");	
			}
		}
		catch(MobileException e)
		{
			System.out.println(e.getMessage());
		}
	}


	public static void searchMobile()
	{
		System.out.println("Enter minimum price:");
		int min=sc.nextInt();
		System.out.println("Enter maximum price:");
		int max=sc.nextInt();
		try 
		{
			ArrayList<Mobiles> mobList=mobser.getRangeMobiles(min, max);
			for(Mobiles mob:mobList)
			{
				System.out.println(mob);
			}
		} 
		catch (MobileException e) 
		{
			System.out.println("Maybe some exception while Fetching");
			e.printStackTrace();
		}
	}


	/*public static void updateQuantity(mobiles mob)
	{

		try
		{
			int dataUpdate=mobser.updateMobileQty(mobileId);
			if(dataUpdate==1)
			{
				System.out.println("Mobile data Updated:");
			}
			else
			{
				System.out.println("Maybe some exception while Updation");	
			}
		}
		catch(MobileException e)
		{
			System.out.println(e.getMessage());
		}
	}*/
}

