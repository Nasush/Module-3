package com.cg.mobpur.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobpur.bean.Mobiles;
import com.cg.mobpur.bean.PurchaseDetails;
import com.cg.mobpur.dao.MobDaoImpl;
import com.cg.mobpur.dao.MobileDao;
import com.cg.mobpur.dao.PurchaseDetailsDao;
import com.cg.mobpur.exception.MobileException;

public class MobileDaoTest 
{

	static PurchaseDetailsDao purdao=null;
	static MobileDao mobdao=null;
	static Mobiles mob=null;
	static PurchaseDetails pd=null;
    
	 @BeforeClass
	    public static void beforeClass() throws MobileException
	    {
	        mobdao=new MobDaoImpl();
	        pd=new PurchaseDetails("Amana","aman@gmail.com",8109453231l,1002,purdao.generatePurchaseId());
	    }
	    @Test
	    public void testAddMob1() throws MobileException
	    {
	        Assert.assertEquals(1,purdao.insertCustomer(pd));
	    }
	    @Test(expected=Exception.class)
	    public void testAddMob2() throws MobileException
	    {
	        Assert.assertEquals(1,purdao.insertCustomer(pd));
	    }
	    @Test
	    public void testSelectMob1() throws MobileException
	    {
	        Assert.assertNotNull(mobdao.getAllMobiles());
	    }
	    public void testSelectMob2() throws MobileException
	    {
	        Assert.assertNotNull(mobdao.getRangeMobiles(5000,20000));
	    }
	   /* public void testUpdate1() throws MobilePurchaseException
	    {
	        Assert.assertEquals(1,mobDao.updateQuantity(1004));
	    }
	    @Test(expected=Exception.class)
	    public void testUpdate2() throws MobilePurchaseException
	    {
	        Assert.assertEquals(0,mobDao.updateQuantity(1234));
	    }
	    public void testDelete1() throws MobilePurchaseException
	    {
	        Assert.assertEquals(1,mobDao.deleteMobiles(1004));
	    }
	    @Test(expected=Exception.class)
	    public void testDelete2() throws MobilePurchaseException
	    {
	        Assert.assertEquals(0,mobDao.deleteMobiles(1234));
	    }*/
}
