package com.cg.mobpur.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;




import java.util.Scanner;





import com.cg.mobpur.bean.Mobiles;
import com.cg.mobpur.bean.PurchaseDetails;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.util.DBUtil;

public class MobDaoImpl implements MobileDao 
{
	Scanner sc=null;
	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
	@Override
	public ArrayList<Integer> getAllMobileIds() throws MobileException 
	{
		ArrayList<Integer> mobIdList = new ArrayList<Integer>();
		String selectQry="Select mobileId from Mobiles";
		Integer ee=0;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				ee=new Integer(rs.getInt("mobileId"));
						
				mobIdList.add(ee);
			}
			
		}
		catch(Exception e)
		{
			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new MobileException(e.getMessage());
			}
		}
		return mobIdList;
	
	
	}

	@Override
	public int getMobileQuantity(Mobiles mob) throws MobileException 
	{
		
		String selectQry="Select quantity from Mobiles where mobileId=?";
		int data=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			
			
			pst.setInt(1,mob.getMobileId());
			rs=pst.executeQuery();
			rs.next();
			data=rs.getInt(1);
			//System.out.println(data);
			
		}
		catch(Exception e)
		{
			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new MobileException(e.getMessage());
			}
		}
		return data;
		
	}

	@Override
	public ArrayList<Mobiles> getAllMobiles() throws MobileException 
	{
		ArrayList<Mobiles> mobList = new ArrayList<Mobiles>();
		String selectQry="Select * from Mobiles";
		Mobiles mob=null;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				mob=new Mobiles(rs.getInt("mobileId"),
						rs.getString("name"),
						rs.getFloat("price"),
						rs.getInt("quantity"));
				mobList.add(mob);
			}
			
		}
		catch(Exception e)
		{
			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
		
		
	}

	
	public int deleteMobile(int mobileId) throws MobileException 
	{
		String delQry="delete from Mobiles where mobileId =?";
		int dataDeleted=0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(delQry);
			pst.setInt(1, mobileId);
			 dataDeleted=pst.executeUpdate();
			System.out.println("data deleted from table:"+dataDeleted);
		}
		catch (Exception e) 
		{
			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new MobileException(e.getMessage());
			}
		}
		
		
		return dataDeleted;
	}

	@Override
	public ArrayList<Mobiles> getRangeMobiles(int min, int max)
			throws MobileException 
	{
		ArrayList<Mobiles> mobList = new ArrayList<Mobiles>();
		String Range="select * from mobiles where price>=? and price<=?";
		Mobiles mob=null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(Range);
			pst.setInt(1, min);
			pst.setInt(2, max);
			rs=pst.executeQuery();
			while(rs.next())
			{
				mob=new Mobiles(rs.getInt("mobileId"),
						rs.getString("name"),
						rs.getFloat("price"),
						rs.getInt("quantity"));
				mobList.add(mob);
			}
			
		}
		catch(Exception e)
		{
			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
	}

	
	public int updateMobileQty(Mobiles mob) throws MobileException 
	{
		String UpdateQry="Update mobiles set quantity=quantity-? where mobileId=?";
		int dataUpdated;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(UpdateQry);
			pst.setInt(1, mob.getQuantity());
			pst.setInt(2, mob.getMobileId());
			//System.out.println(mob.getMobileId());
			//System.out.println(mob.getQuantity());
			 dataUpdated=pst.executeUpdate();
			 
		} 
		 catch (Exception e) 
		{
			 throw new MobileException(e.getMessage());
			
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new MobileException(e.getMessage());
			}
		}
		
		return dataUpdated;
	}

}
