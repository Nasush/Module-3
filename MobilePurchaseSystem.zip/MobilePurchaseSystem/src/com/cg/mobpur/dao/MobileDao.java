package com.cg.mobpur.dao;

import java.util.ArrayList;

import com.cg.mobpur.bean.Mobiles;
import com.cg.mobpur.bean.PurchaseDetails;
import com.cg.mobpur.exception.MobileException;



public interface MobileDao 
{
	public ArrayList<Integer> getAllMobileIds()throws MobileException;
	public int getMobileQuantity(Mobiles mob) throws MobileException; 
	
	public ArrayList<Mobiles> getAllMobiles()throws MobileException;
    public int deleteMobile(int mobileId)throws MobileException;
    public ArrayList<Mobiles> getRangeMobiles(int min,int max)throws MobileException;
    public int updateMobileQty(Mobiles mob)throws MobileException;

}
