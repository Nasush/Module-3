package com.cg.mobpur.exception;

public class MobileException extends Exception
{
	public MobileException(String msg)
	{
		super(msg);
	}
}
