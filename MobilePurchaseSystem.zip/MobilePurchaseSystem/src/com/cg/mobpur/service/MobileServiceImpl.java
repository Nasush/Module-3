package com.cg.mobpur.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobpur.bean.Mobiles;
import com.cg.mobpur.bean.PurchaseDetails;
import com.cg.mobpur.dao.MobDaoImpl;
import com.cg.mobpur.dao.MobileDao;
import com.cg.mobpur.exception.MobileException;

public class MobileServiceImpl implements MobileService
{
MobileDao mobDao=null;
	public MobileServiceImpl() 
	{
		mobDao=new MobDaoImpl();
	}

	@Override
	public ArrayList<Integer> getAllMobileIds() throws MobileException {
		
		return mobDao.getAllMobileIds();
	}

	@Override
	public int getMobileQuantity(Mobiles mob) throws MobileException {
		
		return mobDao.getMobileQuantity(mob);
	}

	@Override
	public boolean validateDigit(int mobileId) throws MobileException 
	{
		String mobileIdPattern="[0-9]{4}";
		if(Pattern.matches(mobileIdPattern,new Integer(mobileId).toString()))
				{
			return true;
				}
		else
		{
		throw new MobileException("Not a valid MobileId");	
		}
		
	}

	@Override
	public ArrayList<Mobiles> getAllMobiles() throws MobileException {
		
		return mobDao.getAllMobiles();
	}

	@Override
	public int deleteMobile(int mobileId) throws MobileException 
	{
	
		return mobDao.deleteMobile(mobileId);
	}

	@Override
	public ArrayList<Mobiles> getRangeMobiles(int min, int max)
			throws MobileException 
			{
		
		return mobDao.getRangeMobiles(min, max);
	}

	@Override
	public int updateMobileQty(Mobiles mob) throws MobileException 
	{
		
		return mobDao.updateMobileQty(mob);
	}

}
