package com.cg.mobpur.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobpur.bean.PurchaseDetails;
import com.cg.mobpur.dao.PurchaseDetailsDao;
import com.cg.mobpur.dao.PurchaseDetailsImpl;
import com.cg.mobpur.exception.MobileException;


public class PurchaseDetailsServiceImpl implements PurchaseDetailsService
{
   PurchaseDetailsDao purDao=null;
   
	public PurchaseDetailsServiceImpl() 
	{
	purDao=new PurchaseDetailsImpl();
    }

	@Override
	public int insertCustomer(PurchaseDetails pd) throws MobileException 
	{
	
		return purDao.insertCustomer(pd);
	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		
		return purDao.generatePurchaseId();
	}

	@Override
	public boolean validateName(String cname) throws MobileException 
	{
		String cnamePattern="[A-Z][A-Za-z]{3,20}";
		if(Pattern.matches(cnamePattern,cname))
				{
			return true;
				}
		else
		{
		throw new MobileException("Valid value should contain maximum 20 alphabets. "
				+ "Out of 20 Characters, first character should be in UPPERCASE");	
		}
		
	}

	@Override
	public boolean validateMailId(String mailId) throws MobileException 
	{
		String mailIdPattern="[A-Za-z0-9]+[@][a-z]+[/.][a-z]+";
		if(Pattern.matches(mailIdPattern,mailId))
				{
			return true;
				}
		else
		{
		throw new MobileException("Not a valid EmailId");	
		}
		
	}

	@Override
	public boolean validatePhoneNo(long phoneNo) throws MobileException 
	{
		
		String phoneNoPattern="[987]{1}[0-9]{9}";
		if(Pattern.matches(phoneNoPattern,new Long(phoneNo).toString()))
				{
			return true;
				}
		else
		{
		throw new MobileException("Not a valid Phone Number");	
		}
		
	}
	 
}
