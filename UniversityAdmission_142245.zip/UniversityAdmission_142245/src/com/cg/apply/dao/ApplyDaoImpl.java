package com.cg.apply.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;
import com.cg.university.util.DBUtil;

public class ApplyDaoImpl implements ApplyDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
    Logger candidateLogger=null;
    
	public ApplyDaoImpl() 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
    	candidateLogger=Logger.getLogger("ApplyDaoImpl.class");
	}

	@Override
	public int addApplicantDetails(ApplicantBean ab) throws ApplicantException 
	{
		String insertQry="INSERT INTO Candidate_Detail(applyid,firstName,lastName,contactNo,email,aggregate,stream) values(?,?,?,?,?,?,?)";
		int dataAdded=0;
		try 
		{

			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setLong(1, generateApplyId());
			pst.setString(2, ab.getfName());
			pst.setString(3, ab.getlName());
			pst.setLong(4, ab.getContactNo());
			pst.setString(5, ab.getEmail());
			pst.setFloat(6, ab.getAggregate());
			pst.setString(7, ab.getStream());
			

			dataAdded=pst.executeUpdate();
			candidateLogger.log(Level.INFO,"Candidate Inserted: "+ab);

		} 
		catch (Exception e)
		{
			candidateLogger.error("This is Exception:"+e.getMessage());
			throw new ApplicantException(e.getMessage());

		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				candidateLogger.error("This is Exception:"+e.getMessage());
				throw new ApplicantException(e.getMessage());

			}

		

	    }

	return dataAdded;

		
		
}

	@Override
	public long generateApplyId() throws ApplicantException 
	{
		String qry="SELECT apply_id_seq.nextval from dual";
		long generatedVal;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getLong(1);
			candidateLogger.log(Level.INFO,"Generated Applicant ID: "+generatedVal);
		} 
		catch (Exception e)
		{
			candidateLogger.error("This is Exception:"+e.getMessage());
			throw new ApplicantException(e.getMessage());
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				candidateLogger.error("This is Exception:"+e.getMessage());
				throw new ApplicantException(e.getMessage());
			}
		}

		return generatedVal;
	}
    
		
	

	@Override
	public ArrayList<ApplicantBean> getApplicantDetails(long applyId) throws ApplicantException 
	{
		ArrayList<ApplicantBean> canList = new ArrayList<ApplicantBean>();
		String selectQry="Select * from candidate_detail where applyid=?";
		ApplicantBean ab=null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setLong(1, applyId);
			 rs=pst.executeQuery();
			while(rs.next())
			{
				ab=new ApplicantBean(rs.getLong("applyId"),
						rs.getString("firstName"),
						rs.getString("lastName"),
						rs.getLong("contactNo"),
						rs.getString("email"),
						rs.getFloat("aggregate"),
						rs.getString("stream"));
				canList.add(ab);
			}
			candidateLogger.log(Level.INFO,"Details of Applicant are: "+canList);
		}
		catch(Exception e)
		{
			candidateLogger.error("This is Exception:"+e.getMessage());
			throw new ApplicantException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				candidateLogger.error("This is Exception:"+e.getMessage());
				throw new ApplicantException(e.getMessage());
			}
		}
		return canList;
		
	}

	@Override
	public ArrayList<Long> getAllApplicantId() throws ApplicantException 
	{
		ArrayList<Long> appIdList = new ArrayList<Long>();
		String selectQry="Select applyId from candidate_detail";
		Long ee=0l;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				ee=new Long(rs.getLong("applyId"));
						
				appIdList.add(ee);
			}
			candidateLogger.log(Level.INFO,"Details of Applicant Ids: "+appIdList);
		}
		catch(Exception e)
		{
			candidateLogger.error("This is Exception:"+e.getMessage());
			throw new ApplicantException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				candidateLogger.error("This is Exception:"+e.getMessage());
				throw new ApplicantException(e.getMessage());
			}
		}
		return appIdList;
		
	}

}
