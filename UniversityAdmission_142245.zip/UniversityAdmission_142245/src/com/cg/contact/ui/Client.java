package com.cg.contact.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;
import com.cg.contact.service.ApplyService;
import com.cg.contact.service.ApplyServiceImpl;

public class Client 
{
	static Scanner sc=null;
	static ApplyService appser=null;
	public static void main(String[] args) 
	{
		sc=new Scanner(System.in);
		appser=new ApplyServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("*********Admission System***********");
			System.out.println("Select an Operation");
			System.out.println("1:Enter Details\n"
					+ "2:View Details based on Applicant Id\n"
					+ "0:Exit");
			System.out.println("********************");
			System.out.println("Please Enter a choice");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:insertApplicant();
			break;
			case 2:viewApplicantDetails();
			break;
			default:System.out.println("Thank you for Applying!!");
			System.exit(0);

			}
		}

	}
	public static void insertApplicant()
	{ 
		try
		{
			System.out.println("Enter First Name:");
			String fname=sc.next();
			if(appser.validateFirstName(fname))
			{
				System.out.println("Enter Last Name:");
				String lname=sc.next();
				if(appser.validateLastName(lname))
				{
					System.out.println("Enter Contact Number:");
					long cno=sc.nextLong();
					if(appser.validateContactNo(cno))
					{
						System.out.println("Enter Email:");
						String email=sc.next();
						if(appser.validateEmail(email))
						{
							System.out.println("Enter Aggregate in qualifying exam:");
							float agg=sc.nextFloat();
							if(appser.validateAggregate(agg))
							{
								System.out.println("Enter Stream:");
								String stream=sc.next();
								if(appser.validateStream(stream))
								{
									ApplicantBean ab=new ApplicantBean();
									ab.setfName(fname);
									ab.setlName(lname);
									ab.setContactNo(cno);
									ab.setEmail(email);
									ab.setAggregate(agg);
									ab.setStream(stream);
									int dataAdded=appser.addApplicantDetails(ab);
									if(dataAdded==1)
									{
										System.out.println("Thank you"+fname+" "+lname+"your Unique Id is"+appser.generateApplyId()+"we will contact you shortly."  );

									}
									else
									{
										System.out.println("Maybe some exception while Addition");	
									}
								}
							}
						}
					}
				}
			}
		}
		catch(ApplicantException e)
		{
			System.out.println(e.getMessage());
		}
	}


	public static void viewApplicantDetails()
	{
		try
		{
			System.out.println("Enter the Applicant Id:");
			Long applyId=sc.nextLong();
			if(appser.validateApplicantId(applyId))
			{
			ArrayList<ApplicantBean> canList=appser.getApplicantDetails(applyId);
			for(ApplicantBean ab:canList)
			{
				System.out.println(ab);
			}
			}
			else
			{
				System.out.println("Sorry no details found!!!");
			}
		} 
		catch (ApplicantException e) 
		{
			System.out.println("Maybe some exception while Fetching");
			e.printStackTrace();
		}
	}
}
