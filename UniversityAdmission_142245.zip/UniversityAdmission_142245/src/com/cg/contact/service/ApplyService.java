package com.cg.contact.service;

import java.util.ArrayList;

import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;

public interface ApplyService 
{
	public int addApplicantDetails(ApplicantBean ab)throws ApplicantException;
	public long generateApplyId()throws ApplicantException;
	public ArrayList<ApplicantBean> getApplicantDetails(long applyId)throws ApplicantException;
	public ArrayList<Long> getAllApplicantId()throws ApplicantException;
	public boolean validateApplicantId(long applyId)throws ApplicantException;
	
    public boolean validateContactNo(long contactNo)throws ApplicantException;
    public boolean validateFirstName(String fname)throws ApplicantException;
    public boolean validateLastName(String lname)throws ApplicantException;
    public boolean validateEmail(String email)throws ApplicantException;
    public boolean validateAggregate(float aggregate)throws ApplicantException;
    public boolean validateStream(String stream)throws ApplicantException;
}
