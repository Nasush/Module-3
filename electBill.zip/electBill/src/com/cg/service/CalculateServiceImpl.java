package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.CalculateDao;
import com.cg.dao.CalculateDaoImpl;
import com.cg.dto.Bill;
import com.cg.exception.BillException;

public class CalculateServiceImpl implements CalculateService
{
	CalculateDao calDao=null;
	public CalculateServiceImpl() 
	{
		calDao=new CalculateDaoImpl();
	}
	@Override
	public int addBillDetails(Bill bill) throws BillException 
	{
		return calDao.addBillDetails(bill);
	}

	@Override
	public ArrayList<Long> getCustomerId() throws BillException 
	{
		return calDao.getCustomerId();
	}

	@Override
	public String getCustomerName(Long consumerNo) throws 
	BillException 
	{
		
		return calDao.getCustomerName(consumerNo);
	}

	@Override
	public boolean validateCustomerId(long cId) throws 
	BillException 
	{
		
		ArrayList<Long> conId=new ArrayList<Long>();
		conId=calDao.getCustomerId();
		int flag=0;
		for(Long i:conId)
			{
				if(cId==i)
				{
					flag=1;
				}
			}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new BillException("Invalid Consumer Number."
					+ "Please check it.");
		}
	}

	@Override
	public boolean validateMeterReading(float lMonReading, 
			float cMonReading)
			throws BillException 
	{

		if(cMonReading>lMonReading)
		{
			return true;
		}
		else
		{
			throw new BillException("Current Month Reading should "
					+ "be greater than"
					+ " last Month Reading");
		}
	}
}
