package com.cg.user.dto;

public class Bill 
{
	private int billNum;
	private long consumerNo;
	private float currentReading;
	private float unitsConsumed;
	private float netAmount;
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public long getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(long consumerNo) {
		this.consumerNo = consumerNo;
	}
	public float getCurrentReading() {
		return currentReading;
	}
	public void setCurrentReading(float currentReading) {
		this.currentReading = currentReading;
	}
	public float getUnitsConsumed() {
		return unitsConsumed;
	}
	public void setUnitsConsumed(float unitsConsumed) {
		this.unitsConsumed = unitsConsumed;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
	public Bill() {
		super();
	}
	public Bill(int billNum, long consumerNo, float currentReading,
			float unitsConsumed, float netAmount) {
		this.billNum = billNum;
		this.consumerNo = consumerNo;
		this.currentReading = currentReading;
		this.unitsConsumed = unitsConsumed;
		this.netAmount = netAmount;
	}
	@Override
	public String toString() {
		return "Bill [billNum=" + billNum + ", consumerNo=" + consumerNo
				+ ", currentReading=" + currentReading + ", unitsConsumed="
				+ unitsConsumed + ", netAmount=" + netAmount + "]";
	}
}
