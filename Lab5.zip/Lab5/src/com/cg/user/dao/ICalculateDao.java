package com.cg.user.dao;

import java.util.ArrayList;

import com.cg.user.dto.Bill;
import com.cg.user.exception.BillException;

public interface ICalculateDao 
{
	public int addBillDetails(Bill bill) throws BillException;
	public ArrayList<Long> getCustomerId()  throws BillException;
	public String getCustomerName(Long consumerNo) throws BillException;
}
