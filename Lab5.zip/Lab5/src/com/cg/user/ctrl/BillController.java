package com.cg.user.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.user.dto.Bill;
import com.cg.user.service.*;

@WebServlet("/BillController")
public class BillController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	private static final float fixedCharge = 100.0F;
	ServletConfig cg=null;
	ICalculateService calcServ=null;
	Bill bill=null;
	public BillController() {
		super();

	}

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		cg=config;
	}

	public void destroy() 
	{
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		calcServ=new CalculateServiceImpl();
		bill=new Bill();
		RequestDispatcher rd=null;
		int dataAdded=0;
		HttpSession session=request.getSession(true);
		String action=request.getParameter("action");
		if(action!=null)
		{
			try
			{
				if(action.equals("ShowBillDetails"))
				{
					String cId=request.getParameter("cno");
					String curr_reading=request.getParameter("curReading");
					String last_reading=request.getParameter("lastReading");
					
					float curr=Float.parseFloat(curr_reading);
					float last=Float.parseFloat(last_reading);
					long consNo=Long.parseLong(cId);
					float unitsConsumed=0.0F;
					float netAmount=0.0F;
					if(calcServ.validateCustomerId(consNo) && 
							calcServ.validateMeterReading(last, curr))
					{
						unitsConsumed=curr-last;
						netAmount=unitsConsumed*1.15F+fixedCharge;
						bill.setConsumerNo(consNo);
						bill.setCurrentReading(curr);
						bill.setNetAmount(netAmount);
						bill.setUnitsConsumed(unitsConsumed);
						dataAdded=calcServ.addBillDetails(bill);
						if(dataAdded==1)
						{
							session.setAttribute("ConsumerNo", consNo);
							session.setAttribute("Units", unitsConsumed);
							session.setAttribute("NetAmt", netAmount);
							rd=request.getRequestDispatcher("DisplayServlet");
							rd.forward(request, response);
						}
						else
						{
							rd=request.getRequestDispatcher("InsertionFail.html");
							rd.forward(request, response);
						}
					}
					else
					{
						rd=request.getRequestDispatcher("CNoInvalid.html");
						rd.forward(request, response);
					}
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				String errMsg=e.getMessage();
				session.setAttribute("ErrorObj", errMsg);
				rd=request.getRequestDispatcher("ErrorPage");
				rd.forward(request, response);
			}
		}
	}

}
