package com.cg.ui;

import java.util.Scanner;

import com.cg.dto.Author;
import com.cg.service.AuthorService;
import com.cg.service.AuthorServiceImpl;

public class AuthorClient 
{
	public static void main(String[] args) 
	{
		AuthorService aser = new AuthorServiceImpl();
		int choice=0;
		Scanner sc = new Scanner(System.in);
		do
		{
			
		System.out.println("1. Insert Author Details");
		System.out.println("2. Search Author");
		System.out.println("3. Delete Author");
		System.out.println("4. Exit");
		System.out.println("Enter your choice: ");
		choice = sc.nextInt();
		
		
		switch(choice)
		{
		case 1: System.out.println("Enter Author first name: ");
				String fname = sc.next();
				System.out.println("Enter Author middle name: ");
				String mname = sc.next();
				System.out.println("Enter Author last name: ");
				String lname = sc.next();
				System.out.println("Enter Author phone no: ");
				String phoneNo = sc.next();
				Author a = new Author();
				a.setFirstName(fname);
				a.setMiddleName(mname);
				a.setLastName(lname);
				a.setPhoneNo(phoneNo);
				aser.addAuthor(a);
				System.out.println("Author details added");
				break;
				
		
		case 2: System.out.println("Enter Author Id to search: ");
				int aid = sc.nextInt();
				Author author1 = aser.findAuthor(aid);
				System.out.println(author1);
				break;
				
		case 3: System.out.println("Enter Author Id to delete");
				int aid1 = sc.nextInt();
				Author author2 = aser.findAuthor(aid1);
				aser.deleteAuthor(author2);
				System.out.println("Author details deleted");
				break;
				
		case 4:
			System.exit(0);
		}
		
		}
		while(true);
			
	}
}
