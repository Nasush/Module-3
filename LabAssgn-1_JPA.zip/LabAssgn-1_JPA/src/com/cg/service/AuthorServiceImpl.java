package com.cg.service;

import com.cg.dao.AuthorDao;
import com.cg.dao.AuthorDaoImpl;
import com.cg.dto.Author;

public class AuthorServiceImpl implements AuthorService
{
	AuthorDao aDao = new AuthorDaoImpl();
	@Override
	public void addAuthor(Author auth) 
	{
		aDao.addAuthor(auth);		
	}

	@Override
	public void deleteAuthor(Author auth) 
	{
		aDao.deleteAuthor(auth);
	}

	@Override
	public Author findAuthor(int aid)
	{
		return aDao.findAuthor(aid);
	}

}
