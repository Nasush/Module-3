package com.cg.service;

import com.cg.dto.Author;

public interface AuthorService 
{
	void addAuthor(Author auth);
	void deleteAuthor(Author auth);
	Author findAuthor(int aid);
}
