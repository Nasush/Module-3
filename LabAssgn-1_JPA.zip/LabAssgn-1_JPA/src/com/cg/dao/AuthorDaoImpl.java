package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Author;

public class AuthorDaoImpl implements AuthorDao
{
	EntityManager em;
	
	public AuthorDaoImpl() 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		em = emf.createEntityManager();
	}
	@Override
	public void addAuthor(Author auth) 
	{
		em.getTransaction().begin();
		em.persist(auth);
		em.getTransaction().commit();
	}


	@Override
	public void deleteAuthor(Author auth) 
	{
		em.getTransaction().begin();
		em.remove(auth);
		em.getTransaction().commit();		
		
	}

	@Override
	public Author findAuthor(int aid) 
	{
		Author a = em.find(Author.class, aid);	
		return a;
		
	}

}
