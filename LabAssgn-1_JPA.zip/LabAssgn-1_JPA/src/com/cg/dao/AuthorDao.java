package com.cg.dao;

import com.cg.dto.Author;

public interface AuthorDao 
{
	void addAuthor(Author auth);
	void deleteAuthor(Author auth);
	Author findAuthor(int aid);
}
