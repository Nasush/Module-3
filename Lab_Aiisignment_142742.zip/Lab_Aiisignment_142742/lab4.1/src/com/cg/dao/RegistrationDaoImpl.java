package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.cg.dto.Registration;
import com.cg.util.DBUtil;

public class RegistrationDaoImpl implements RegistrationDao
{
    Connection con=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    
    @Override
    public int getDetails(Registration register) throws SQLException 
    {
        Registration user=null;
        con=DBUtil.getCon();
        System.out.println("Got Connection :");
        String insertQry="insert into RegisteredUsers(firstname,lastname,password,"
                + "gender,skillset,city) values(?,?,?,?,?,?)";
        pst=con.prepareStatement(insertQry);
        
        String fNm=register.getfName();
        String lNm=register.getlName();
        String pwd=register.getPassword();
        char gen= register.getGender();
        String skl=register.getSkillset();
        String cty=register.getCity();
        
        pst.setString(1,fNm);
        pst.setString(2, lNm);
        pst.setString(3, pwd);
        pst.setString(4, String.valueOf(gen));
        pst.setString(5, skl);
        pst.setString(6, cty);
        
        
        return pst.executeUpdate();
    }

}