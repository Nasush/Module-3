package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Consumer;
import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;
import com.cg.exception.ConsumerException;

public interface ElecBillService 
{
	public int addBillDetails(ElectricityBill elecBill) throws BillException,Exception;
	public long generateBillNumber() throws BillException,Exception;
	public ArrayList<Consumer> getAllConsumerDetails() throws ConsumerException;
	public Consumer getConsumerById(long consumerNumber) throws ConsumerException;
	public ArrayList<ElectricityBill> showBillDetails(long consumerNo) throws BillException;
	
	public float calcUnitConsumed(float lMonMeterReading,float cMonMeterReading)throws BillException,Exception;
	public float calcNetAmount(float unitConsumed)throws BillException,Exception;
	public String getConsumerName(int ConsumerNumber) throws BillException,Exception;
	
	public boolean validateLMonMeterReading(float lMonMeterReading) throws BillException,Exception;
	public boolean validateCMonMeterReading(float cMonMeterReading) throws BillException,Exception;
	public boolean validateMeterReading(float lMonMeterReading,float cMonMeterReading)throws BillException,Exception;
	public boolean validateConsumerNumber(int consumerNumber) throws BillException, Exception;
}
