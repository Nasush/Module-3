package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TimeServlet
 */
@WebServlet(name = "TimeServletName", 
urlPatterns = { "/TimeServletMap" })

public class TimeServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    
    public TimeServlet() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("Control is in INit");
	}

	
	public void destroy() 
	{
		System.out.println("Control is in destroy");

	}

	
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, 
			IOException {
		doPost(request,response);

	}

	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			IOException {
		PrintWriter out = response.getWriter();
		LocalDate date=LocalDate.now();
		out.print("System date and Time is :" +LocalDateTime.now());
		
	}

}
