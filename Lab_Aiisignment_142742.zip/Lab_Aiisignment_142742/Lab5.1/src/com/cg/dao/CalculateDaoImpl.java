package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.Bill;
import com.cg.exception.BillException;
import com.cg.util.DBUtil;

public class CalculateDaoImpl implements CalculateDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	@Override
	public int addBillDetails(Bill bill) throws BillException 
	{
		
		String insertQry="insert into billdetails(bill_num,consumer_num,cur_reading,"
				+ "unitConsumed,netAmount) values(?,?,?,?,?)";
		int dataAdded=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, genetateBillNum());
			pst.setLong(2, bill.getConsumerNum());
			pst.setFloat(3, bill.getCurrReading());
			pst.setFloat(4, bill.getUnitsConsumed());
			pst.setFloat(5, bill.getNetAmount());
			dataAdded=pst.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new BillException(e.getMessage());
		}
		return dataAdded;
	}
	
	public  int genetateBillNum() throws BillException 
	{
		String qry="Select seq_bill_num.NEXTVAL from dual";
		int generatedVal=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
		} 
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new BillException(e.getMessage());
			}
		}
		return generatedVal;
	}
	@Override
	public ArrayList<Long> getCustomerId() throws BillException
	{
		
		String selectQry="SELECT consumer_num FROM consumers";
		ArrayList<Long> conList=new ArrayList<Long>();
		Long conId;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				conId=rs.getLong(1);
				conList.add(conId);
			}
		} 
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		}
		finally
		{
			try 
			{
				
				st.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new BillException(e.getMessage());
			}
		}
		return conList;
		
	}

	@Override
	public String getCustomerName(Long consumerNo) throws
	BillException 
	{
		
		String selectQry="SELECT consumer_name FROM consumers where consumer_num=?";
		String cname=null;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setLong(1, consumerNo);
			rs=pst.executeQuery();
			rs.next();
			cname=rs.getString(1);
		} 
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new BillException(e.getMessage());
			}	
		}
		return cname;
	}
	}


