package com.cg.user.dto;

public class Login
{
private String usernamer;
private String password;

public String getUsernamer()
{
	return usernamer;
}
public void setUsernamer(String usernamer)
{
	this.usernamer = usernamer;
}
public String getPassword()
{
	return password;
}
public void setPassword(String password)
{
	this.password = password;
}
public Login(String usernamer, String password)
{
	super();
	this.usernamer = usernamer;
	this.password = password;
}
public Login()
{
	super();
}
@Override
public String toString()
{
	return "Login [usernamer=" + usernamer + ", password=" 
     + password + "]";
}



}
